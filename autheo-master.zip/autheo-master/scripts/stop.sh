pkill -f autheo 
