package gp.e3.autheo.authentication.domain.exceptions;

public class ValidDataException extends Exception{

	/**
	 * Generated serial version
	 */
	private static final long serialVersionUID = 1L;

	public ValidDataException(String msj){
		super(msj);
	}
}
