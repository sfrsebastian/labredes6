package gp.e3.autheo.authorization.infrastructure;

public class AuthorizationConfig {
	
	
}